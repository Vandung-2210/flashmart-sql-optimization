# Báo Cáo Giải Trình Chiến Lược Dàn Trang (Layout Strategy)

CSS Grid sinh ra để giải quyết không gian hai chiều (2D - cả hàng lẫn cột đồng thời), giúp kiểm soát toàn bộ khung cấu trúc tổng thể trang (Macro Layout). Nó cho phép đặt các thành phần tự do ở bất kỳ vị trí ô lưới nào (`grid-column: span 2`, `grid-row: span 2`) mà không cần bọc các lớp `div` trung gian, giữ cấu trúc DOM phẳng và trong sáng.

Ngược lại, Flexbox là công cụ một chiều (1D), lý tưởng cho các Component chi tiết (Micro Layout) như Navbar, Toolbar, thẻ Card. Flexbox vận hành theo cơ chế nội dung quyết định kích thước (Content-first), tự động căn đều (`justify-content: space-between`), căn giữa trục vuông góc (`align-items: center`) và tự xuống hàng mượt mà (`flex-wrap: wrap`) khi độ dài văn bản thay đổi linh hoạt.