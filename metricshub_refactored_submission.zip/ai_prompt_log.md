# Nhật Ký Tương Tác AI (AI Prompt Log) - Dự Án MetricsHub

### Prompt 1 (Bước 1: Phân tích quy tắc 1D vs 2D & Xóa bỏ Div Soup)
* **Prompt gửi AI:** "Khi tôi cần một bố cục Bento Dashboard mà một phần tử con phải chiếm chính xác 2 hàng và 2 cột (span 2 rows, 2 columns) đan xen với các widget nhỏ khác, tôi nên chọn CSS Grid hay Flexbox? Tại sao Flexbox lại chật vật và tạo ra 'Div Soup' trong bài toán này?"
* **AI phản hồi tóm tắt:** Flexbox chỉ tính toán theo một trục tại một thời điểm (1D). Để giả lập ô 2 hàng 2 cột trong Flexbox, lập trình viên buộc phải lồng các container `.column` và fix cứng `height`, tạo ra cấu trúc DOM sâu ("Div Soup") và dễ gãy vỡ. CSS Grid quản lý cả 2 trục đồng thời (2D), chỉ cần `grid-column: span 2` và `grid-row: span 2` trực tiếp trên phần tử con mà không cần bất kỳ thẻ bao bọc phụ nào.

### Prompt 2 (Bước 2: Phản biện kiến trúc Bootstrap cho Pricing)
* **Prompt gửi AI:** "Trong Bootstrap 5, sự khác biệt giữa `col-12 col-md-4` và `col-sm-4` là gì? Tại sao nên dùng Bootstrap 12-column grid thay vì tự viết CSS tay cho 3 cột Bảng giá?"
* **AI phản hồi tóm tắt:** `col-12 col-md-4` đảm bảo giao diện full width 100% trên màn hình nhỏ/mobile và tự động dàn thành 3 cột đều nhau trên breakpoint `md` (>=768px). Dùng Bootstrap tận dụng hệ thống grid 12 cột chuẩn hóa, nhất quán `gutters` (`g-4`), không cần viết mã Media Query thủ công, giảm thiểu rủi ro lỗi float/clear và tăng tốc độ phát triển.

### Prompt 3 (Bước 3: Mở rộng kiến thức về gap & căn lề bên trong Widget)
* **Prompt gửi AI:** "Thuộc tính `gap` hoạt động thế nào trong cả CSS Grid và Flexbox? Làm thế nào để kết hợp Flexbox bên trong một ô CSS Grid (ví dụ: căn giữa icon và text của Chart A)?"
* **AI phản hồi tóm tắt:** `gap` tạo khoảng cách trực tiếp giữa các item con mà không làm phình kích thước hoặc gây tràn lề như `margin` cũ. Trong kiến trúc hiện đại: CSS Grid quản lý layout cha bên ngoài, còn mỗi `.widget` bên trong có thể bật `display: flex; align-items: center; justify-content: center;` để căn chỉnh nội dung vi mô hoàn hảo.